def receive():
    return "这是来自hm的文件"
