def send(test):
    print("Sending %s ..." % test)
